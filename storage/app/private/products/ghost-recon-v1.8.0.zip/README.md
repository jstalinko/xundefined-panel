# Ghost Recon Framework v1.8.0

Core DNS footprinting and subdomain brute-force scanner.

Build Date: 2026-09-19
Security: Verified Genuine Archive
